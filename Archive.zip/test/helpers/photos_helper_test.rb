require 'test_helper'

class PhotosHelperTest < ActionView::TestCase
end
