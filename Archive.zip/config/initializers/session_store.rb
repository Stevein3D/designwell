# Be sure to restart your server when you modify this file.

Designwell::Application.config.session_store :cookie_store, key: '_designwell_session'
